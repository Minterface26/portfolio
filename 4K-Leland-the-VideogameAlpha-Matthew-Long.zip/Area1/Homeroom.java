import java.util.Scanner;

public class Homeroom {
  private static Scanner scan = new Scanner(System.in);
  private static int choice;

  public static void begin() {
    System.out.println("\nYour eyes shoot open. Sunlight is shining into your room. Mr.Yen is calling your name.");
    System.out.print("\nEnter your name: ");
    String name = scan.nextLine();
    Character.setName(name);
    System.out.println("\nAh, that's right. Your name is " + Character.getName() + ".");
    Character.setRole();
    Character.setMoves();
    

    
    System.out.println("\nYou yawn. Mr.Yen tells you that tutorial is ending and you need to go to your next class. He tells you something about bullyism reaching an all-time high recently and that it's dangerous to go alone, blah blah,..you're falling asleep again already. But it's a beautiful day in the Quad and those darned singing birds are keeping you up.");
    Homeroom.quad();
  }

  public static void quad() {
    System.out.println("\n\t1. Look around\n\t2. Visit the shop\n\t3. Go to your desk\n\t4. Leave J-4");
    choice = scan.nextInt();
    if(choice == 1) {
      System.out.println("\nYou look around, there are a few people to talk to.");
      Homeroom.YenPeople();
    }
    else if(choice == 2) {
      System.out.println("\nYou talk to Parsa, he has some goods from a totally legal website this time.");
      Shop.parsa_sShop();
    }
    else if(choice == 3) {
      System.out.println("\nYou sit at your desk, with  slight chagrin from Mr.Yen as you should be in a different class.");
      Homeroom.yourDesk();
    }
    else if(choice == 4) {
      System.out.println("\nYou say goodbye to Mr.Yen and begin your journey.");
      Quad.move();
    }
    else {
      Homeroom.quad();
    }
  }

  public static void yourDesk() {
    System.out.println("\n\t1. Look around\n\t2. Check status\n\t3. Rest\n\t4. Leave");
    choice = scan.nextInt();
    if(choice == 1) {
      System.out.println("\nYour desk is just the way you left it, P.E. clothes near you in a corner, and a few pencils left behind.");
      Homeroom.yourDesk();
      }
    else if(choice == 2) {
     // Character.status();
      Homeroom.yourDesk();
    }
    else if(choice == 3) {
      System.out.println("\nWell, I guess you can sleep for this break, says Mr.Yen");
      Character.fullHeal();
      Homeroom.yourDesk();
    }
    else if(choice == 4) {
      System.out.println("You leave your desk as messy as you left it.");
      Homeroom.quad();
    }
    else {
      Homeroom.yourDesk();
    }
  }
  public static void YenPeople() {
    System.out.println("\n\t1. Kenneth \n\t2. Daniel \n\t3. Maggie\n\t4. Leave");
    choice = scan.nextInt();
    if(choice == 1) {
      System.out.println("\n Wanna see me do a flip?");
      System.out.println("\n Oh okay...SHEEESH mans landed it");
      Homeroom.YenPeople();
      }
    else if(choice == 2) {
     System.out.println("Have you heard the tragedy of Darth Plageuis the Wise?");
      Homeroom.YenPeople();
    }
    else if(choice == 3) {
      System.out.println("Don't bother me, I'm working on world domination");
      Homeroom.YenPeople();
    }
    else if(choice == 4) {
      System.out.println("You have a sudden twinge of anxiety and decide not to talk to people.");
      Homeroom.quad();
    }
    else {
      Homeroom.YenPeople();
    }
  }
}