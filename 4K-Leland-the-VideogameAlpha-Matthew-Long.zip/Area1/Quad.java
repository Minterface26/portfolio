
//. //folder//file
import java.util.*;
import java.lang.*;

public class Quad {
  private static Scanner scan = new Scanner(System.in);
  private static Random rand = new Random();
  private static String move;
  private static int x = 18;
  //18 for x
  private static int y = 2;
  private static int top = 8;
  public static int count = 0;
  private static boolean isSmallGrass = true;
  
 
 
  //Obstacle ob2 = new Obstacle("🌳", "mush");
  
  public static String[] map = 
    { "🌳🌳🌳🌳🌳                     🌳🌳🌳🌳",
      "🌳🌳🌳🌳   🥽                🌳🗣️🌳🌳🌳",
      "🌳🌳🌳                          🌳      ",
      "       🍃🍃🍃🍃🍃🍃🍃🍃🍃🍃            ",
      "       🍃🍃🍃🍃🍃🍃🍃🍃🍃🍃            ",
      "       🍃🍃🍃🍃🍃🍃🍃🍃🍃🍃            ",
      "       🍃🍃🍃🍃🍃🍃🍃🍃🍃🍃            ",
      "   💀                           💨🌳🌳  ",
      "                  👣             🌳🌳🌳  ",
      "🍃🍃🍃🍃🍃                   🌳🌳🌳🌳🌳",
      "🍃🍃🍃🍃🍃🍃🍃              🌳🌳🌳🌳🌳" };
//24 or 23 where is starts
  //20 for the bottom
  //x= 26
  //🌳 = =
  //🍃 = ^
  
  

  // upper corner is Front of School(different people), maybe call it E-wing
  // upper right corner is ♝ Cafeteria and Band Area, maybe C-Wing
  // Back right corner is J-wing(maybe?)
  // Back left corner is G-wing

  /*
   * {"^^^^^^^^^^                 ^^^^",
   * "^^^^^  ♛                   ^♝^^",
   * "^^^                           ^",
   * "       ^^^^^^^^^^^^^^^^^^^    ",
   * "       ^^^^^^^^^^^^^^^^^^^     ",
   * "       ^^^^^^^^^^^^^^^^^^^     ",
   * "       ^^^^^^^^^^^^^^^^^^^     ",
   * "    ♝                      ♜===",
   * "               ✪         =====",
   * "^^^^^                   =======",
   * "^^^^^^^              ==========";
   */
  // int width

// private static char n =  '\ud83c\udf33';
  private static char za = '\ud83c\udf43';
  public static void move() {
    //System.out.println(n);
    //n = \ud83c\udf33
    boolean running = true;
    System.out.println("\nMove with W, A, S, and D.");
    while (running) {
      // os.clear maybe here?
      Quad.printMap();
      move = scan.nextLine();
      Quad.getMove(move);

      if (x == 32 && y == 3) {
        Quad.printMap();
        System.out.println("\nYou walk along the edge of the C-wing but enter the FIELD.");
        // Homeroom.town();
        break;
      } else if (x == 31 && y == 9) {
        Quad.printMap();
         System.out.println("\nYou arrive at the C-wing. The land of Speech,Band, and Mathematics.");;
        // Fazoria.fazoria();
        break;
      } else if (x == 3 && y == 3) {
        Quad.printMap();
        System.out.println("\nYou arrive at the K and H-wing. The land of History and Culture.");
        // VarDormin.varDormin();
        break;
      } else if (x == 11 && y == 9) {
        Quad.printMap();
        System.out.println("\nYou arrive at the F-wing. The land of Science");
        // Yandelport.yandelport();
        break;
      } else if(x == 19 && y == 2) {
        Quad.printMap();
        System.out.println("\nYou are back at Mr.Yen's class.");
        Homeroom.quad();
        
      } else if((map[top].codePointAt(map[top].indexOf(map[top].substring(x, (x + 1)))) == 127811)){
        //System.out.println("harder encounter");
        System.out.println(map[top].indexOf(map[top]));
        Battle.advancedSpawning();
      }    else if((map[top].codePointAt(map[top].indexOf(map[top].substring(x, (x + 1)))) == 127811 && isSmallGrass == true)) {
        
        int z = 1;
        //random chance out of 3 to get an encounter
        int g = (int)Math.random()*3;
        if(g == z) {
          Battle.randEncounter();
          } 
        } 
  
     //&& map[top].substring(x,x+1).toCharArray()[0] == n
        //&& x >= 26
      } 
      

      
    }
      
  

  public static void getMove(String move) {
    if (move.equals("w") || move.equals("W")) {
      top--;
      y++;
    } else if (move.equals("a") || move.equals("A")) {
      x--;
    } else if (move.equals("s") || move.equals("S")) {
      top++;
      y--;
    } else if (move.equals("d") || move.equals("D")) {
      x++;
    }
    // if go out of bounds on the sides
    if (x > map[0].length() - 1) {
      x = map[0].length() - 1;
    }
    if (x < 0) {
      x = 0;
    }
    // if go out of bounds on the top or bottom
    if (top > map.length - 1) {
      top = map.length - 1;
      y = 0;
    }
    if (y > map.length - 1) {
      top = 0;
      y = map.length - 1;
    }
  }

  public static void printMap() {
    System.out.println("======================================");
    // gets each row and actually prints the row with no character?
    for (int a = 0; a < top; a++) {
      System.out.println(map[a]);
    }
    // Top waits for the map to be printed. Then it prints up to the Character
    // symbol position(not including it) and past the position for that single line
    System.out.print(map[top].substring(0, x));

    System.out.print(Character.printSymbol());

    System.out.print(map[top].substring(x + 1, map[top].length()));
    System.out.println();

    // Prints the rest of the rows starting from the end of top's iteration(where
    // the player character is)
    for (int d = top; d < top + y; d++) {
      System.out.println(map[d + 1]);
    }
 System.out.println("======================================");
    System.out.println("Life: " + Character.getLife() + "/" + Character.getMaxLife() + "\t\tX: " + x + "\tY: " + (y+1));
  }
}