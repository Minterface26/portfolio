import java.util.*;
public class dancerMoves extends Move {
  
  private static ArrayList<dancerMoves> moveList = new ArrayList<dancerMoves>();

  public dancerMoves(String n, String t, String cha) {
  super(n,t, cha);
  
}

  
public static void randMoves3() {
    int r =  (int)(Math.random()*4);
  dancerMoves m1 = new dancerMoves("imamaverick", "dancer", "nothing");
  dancerMoves m2 = new dancerMoves("jump-land","dancer", "nothing");
  dancerMoves m3 = new dancerMoves("slide","dancer", "nothing");
  dancerMoves m4 = new dancerMoves("heel exchange","dancer", "nothing");
  setPosMoves(m1);
  setPosMoves(m2);
  setPosMoves(m3);
  setPosMoves(m4);
  moveList.add(m1);
  moveList.add(m2);
  moveList.add(m3);
  moveList.add(m4);
  
}
public static dancerMoves getMoveinList(int i) {
  return moveList.get(i);
}

  
}