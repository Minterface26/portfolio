public class statusRestore extends Item {
  private static int probability = 1;
  
//tongue-tied, infatuated, 

  public statusRestore() {
    super();
    setCategory("Potion");
    setEffect(0);
     
    
  }
  public statusRestore(String n, String cat, int probabilityLimit ) {
    super(n,cat);
    setCategory("statusRestore");
    probability = (int)(Math.random()*probabilityLimit);
    
    
  }
  

  public int getEffect() {
    return super.getEffect();
  }
  public int getProbability() {
    return probability;
  }
  public void setProbability(int limit) {
    probability = (int)(Math.random()*limit);
  }
  

  
  
}