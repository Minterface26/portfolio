import java.util.*;
public class Move {
  private static ArrayList<Move> posMoves = new ArrayList<Move>();
  //pos moves instead

  
  //Imma Maverick, Jump-land, Slide, CameraFlash
  private String name;
  private int dmg = 0;
  private String type;
  private int times = 0;
  private String statusChange = "nothing";

public Move() {
  name = "Kick";
  dmg = 1;
  type = "dancer";
  
}
public Move(String n, String ty, String cha) {
  name = n;
  dmg = 1;
  type = ty;
  setStatusChange(cha);
  //times = t;
  //t++;
}
public static String getTypefromInt(int j) {
  if(j == 1) {
    return "dancer";
  }
  else if(j == 2) {
    return "debater";
  }
  else if(j ==3) {
    return "designer";
  }
  else {
    return "dancer";
  }
}
  //maybe make a constructor for all the moves

public String getName() {
  return name;
}
public int getDmg() {
  return dmg;
} 
public String getType() {
  return type;
}
public void setType(String t) {
  type = t;
}
public void setDmg(int d) {
  dmg = d;
}
public void setStatusChange(String ch) {
  statusChange = ch;
}
public String getStatusChange() {
  return statusChange;
}
public static ArrayList<Move> getPosMoves() {
  return posMoves;
}
  
public static ArrayList<String> getStringMoves(ArrayList<Move> g) {
  ArrayList<String> res = new ArrayList<String>();
  String part;
  for(int i = 0; i < g.size();i++) {
    part = g.get(i).getName() + ": " + g.get(i).getType() + ": "+ g.get(i).getDmg();
    res.add(part);
  }
  return res;
}
public static void setPosMoves(Move m) {
  posMoves.add(m);
}
  

public static String tos(Move z) {
  String res = z.name + z.dmg + z.type;
  return res;
}

//Debater super effective towards designer, designer super effective towards dancer, dancer super effective towards debater

  


  
}

