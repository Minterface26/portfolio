import java.util.*;
public class Item {
  //type can be status,
  //maybe re-add the toWho variable
  private String name;
  private String category;
  private int effect;
  private static ArrayList<Item> items = new ArrayList<Item>();

  public Item() {
    name = "Item1";
    category = "Potion";
    effect = 0;
  }

  public Item(String n, String tp) {
    name = n;
    category = "Potion";
    effect = 0;
  }
  public String getName() {
    return name;
  }
  public String getCat() {
    return category;
  }
  public int getEffect() {
    return effect;
  }
  public void setCategory(String c) {
    category = c;
  }
  public void setEffect(int f) {
    effect = f;
  }
  


  
}