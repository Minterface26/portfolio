import java.util.*;  
public class Enemy {
 public static String name;
  public static String type;
  private static int life;
  private static int minDamage;
  private static int maxDamage;
  private static int speed;
  private static ArrayList<Enemy> currEnemies = new ArrayList<Enemy>();
  private static int barrier = 2;
  private static String[] enemyNames = {"Sarah", "Leo", "Debater1", "Debater2", "Designer1", "Designer2"};
  //private static ArrayList<Enemy> advancedEnemies = new ArrayList<Enemy>();
  //DONT PUT MARTIN IN, you dont know if he is comfortable

  public Enemy() {
    name = "Sarah";
    type = "dancer";
    life = 5;
    minDamage = 1;
    maxDamage = 3;
    speed = 1;
  }
  public Enemy(String n, String t, int l, int min, int max, int s) {
    name = n;
    type = t;
    life = l;
    minDamage = min;
    maxDamage = max;
    speed = s;
  }
public static String getAName(int i) {
  return enemyNames[i];
}
public static int getNamesLength() {
  return enemyNames.length;
}
public static int getBarrier() {
  return barrier;
}

public static void checkStats(Enemy a) {
  //finds the exact instance enemy that is in play
  String res = "";
  for(int i = 0;i < currEnemies.size();i++) {
    if(a.equals(currEnemies.get(i))) {
      res = a.getName() + "," +a.getType() + "," + a.getLife() + "," + a.getMinDamage() + "," + a.getMaxDamage() + "," + a.getSpeed();
    }
  }
  System.out.println(res);
}
public static void addtoCurr(Enemy e) {
  currEnemies.add(e);
}
public static String getCurrType(int one) {

     return currEnemies.get(one).getType();
  
  
}


  
  public String getName() {
    return name;
  }
  public void setName(String n) {
    name = n;
  }
  public String getType() {
    return type;
  }
  public void setType(String ty) {
    type = ty;
  }
  public int getLife() {
    return life;
  }
  public void setLife(int l) {
    life = l;
  }
  public int getMinDamage() {
    return minDamage;
  }
  public void setMinDamage(int min) {
    minDamage = min;
  }
  public int getMaxDamage() {
    return maxDamage;
  }
  public void setMaxDamage(int max) {
    maxDamage = max;
  }
  public int getSpeed() {
    return speed;
  }
  public void setSpeed(int s) {
    speed = s;
  }


  
  
  
  
}