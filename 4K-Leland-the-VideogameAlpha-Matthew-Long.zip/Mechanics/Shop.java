import java.util.Scanner;

public class Shop {
  private static Scanner scurn = new Scanner(System.in);
  private static int choice;
  private static int sp = 3;

  public static void changePoints(int i) {
    sp += i;
  }

  public static int getPoints() {
    return sp;
  }

  public static void parsa_sShop() {
    System.out.println("\nParsa: \"Welcome to Parsa's shop! The totally legitimate place for buying random goods\"");
    System.out.println("\nYou have " + sp + " Spirit Points.");
    System.out.println("\n\t1. Lemonade - 5 Spirit Points \n\t2. statRestore - 8 Spirit Points \n\t3. Leave");
    choice = scurn.nextInt();
    if(choice == 1) {
      if(sp >= 3) {
        sp -= 3;
        Battle.changeNumPots(1);
        System.out.println("\nYou purchased the Potion! Use it to heal in battle.");
      }
      else {
        System.out.println("\nNot enough Spirit Points!");
      }
      Shop.parsa_sShop();
    }
    else if(choice == 2) {
      if(sp >= 8) {
        sp -= 8;
        Battle.changeNumRestores(1);
        System.out.println("\nYou purchased the statRestore! You can now save yourself from statusEffects for one battle.");
      }
      else {
        System.out.println("\nNot enough Spirit Points!");
      }
      Shop.parsa_sShop();
    }
    else if(choice == 3) {
      System.out.println("\nYou exit the shop.");
      Homeroom.quad();
    }
    else {
      Shop.parsa_sShop();
    }
  }
}

  

  