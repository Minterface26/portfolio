import java.util.*;
public class debaterMoves extends Move {
  
  private static ArrayList<debaterMoves> moveList = new ArrayList<debaterMoves>();
  
public debaterMoves(String n, String t, String cha) {
  super(n,t, cha);
  
}

  
public static void randMoves2() {
    int r =  (int)(Math.random()*4);
  debaterMoves m1 = new debaterMoves("argument","debater", "nothing" );
  debaterMoves m2 = new debaterMoves("inflection","debater", "nothing");
  debaterMoves m3 = new debaterMoves("restatement","debater", "tongue-tied");
  debaterMoves m4 = new debaterMoves("swift point","debater", "nothing");
  setPosMoves(m1);
  setPosMoves(m2);
  setPosMoves(m3);
  setPosMoves(m4);
  moveList.add(m1);
  moveList.add(m2);
  moveList.add(m3);
  moveList.add(m4);
  
}

public static debaterMoves getMoveinList(int i) {
  return moveList.get(i);
}

  
}