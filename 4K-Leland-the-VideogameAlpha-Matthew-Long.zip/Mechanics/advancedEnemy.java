import java.util.*;  
public class advancedEnemy extends Enemy {
  private static ArrayList<advancedEnemy> advancedEnemies = new ArrayList<advancedEnemy>();
  //if need the names advancedEnemies will hold the names of every advancedEnemy
  
 // private static ArrayList<String> posMoves;
  private static ArrayList<Move> moves = new ArrayList<Move>();

  public advancedEnemy() {
    super();
    int g = (int) Math.random()*3;
    if(g == 0) {
      moves.add(designerMoves.getMoveinList(0));
      moves.add(designerMoves.getMoveinList(1));
      moves.add(designerMoves.getMoveinList(2));
      moves.add(designerMoves.getMoveinList(3));
    } else if(g == 1) {
      moves.add(dancerMoves.getMoveinList(0));
      moves.add(dancerMoves.getMoveinList(1));
      moves.add(dancerMoves.getMoveinList(2));
      moves.add(dancerMoves.getMoveinList(3));
    } else if(g == 2) {
      moves.add(debaterMoves.getMoveinList(0));
      moves.add(debaterMoves.getMoveinList(1));
      moves.add(debaterMoves.getMoveinList(2));
      moves.add(debaterMoves.getMoveinList(3));
    } 
  }
  public advancedEnemy(String n, String t, int l, int min, int max, int s) 
  {
    super(n,t,l,min,max,s);
    
  }





  
  

  public static advancedEnemy getAdvancedEnemy(int i) {
    return advancedEnemies.get(i);
  }
  public static void addToAdvancedEnemies(advancedEnemy ad) {
    advancedEnemies.add(ad);
  }

  
  public static ArrayList<Move> getMoveList() {
    return moves;
  }

  
  public static void addToMoveList(Move m) {
    moves.add(m);
  }
  public static Move getMoveinMoveList(int g) {
    return moves.get(g);
  }
  
  public static void setMoveList(int index, Move m) {
    moves.set(index, m);
  }
  
  
}