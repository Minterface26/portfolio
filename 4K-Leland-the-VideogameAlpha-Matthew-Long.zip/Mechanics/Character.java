import java.util.*;
public class Character {
  private static Scanner scan = new Scanner(System.in);
  private static String name;
  private static String role;
  private static String symbol;
  private static int life;
  private static int maxLife;
  private static int minDamage;
  private static int maxDamage;
  private static int speed;
  private static ArrayList<Move> moveset = new ArrayList<Move>();
  private static ArrayList<Item> inventory_ = new ArrayList<Item>();

  public static void status() {
    System.out.println("\nName: " + name + "\nRole: " + role + "\nLife: " + life + "/" + maxLife + "\nPower: " + minDamage + "-" + maxDamage + "\nSpeed: " + speed + ". You have " + inventory_.size() + "items left.");
   // "\nGold: " + Shop.getGold())
    //"\nPotions: " + Battle.getNumPots()
  }
  public static void addToInventory(Item it) {
    inventory_.add(it);
  }
  public static void removeFromInventory(int b) {
    inventory_.remove(b);
  }
  
  public static Item getItem(int i) {
    return inventory_.get(i);
  }
  public static void setSymbol(String emoji) {
    symbol = emoji;
  }
  /*public static ArrayList<Potion> getPotList(int i) {
    ArrayList<Potion> res = new ArrayList<Potion>();
    for(int z = 0; z < inventory_.size();z++) {
      if((inventory_.get(z)) instanceof Potion) {
        
      }
    }
  }*/
  public static String printItemList() {
    String res = "[ ";
    int z = 0;
    for(int x = 0; x < inventory_.size();x++) {
      z = x+1;
      res += z + "." + inventory_.get(x).getName() + ":" + inventory_.get(x).getCat() + ":" + inventory_.get(x).getEffect() + ", ";
    }
    res += "]";
    return res;
  }

  

  public static void gameOver(String death) {
    System.out.println("\nYOU HAVE DIED!\n\n" + name + "'s quest has come to an end. " + death);
    System.exit(0);
  }
  

  /*public static void gameWon() {
    System.out.println("\nYou return to Emperor Kalahan and tell him that you have defeated the evil plaguing the land of Zariadon. He is greatly pleased and has a ceremony across the entire city of Kalldirid in honor of you.");
    System.out.println("\n\"Hail to the intrepid " + name + "!\"");
    System.out.println("\n\n\nYou won! Thank you for playing!\n");
    System.exit(0);
  }*/
  
//heals to full
  public static void fullHeal() {
    life = maxLife;
  }

  public static void setName(String str) {
    name = str;
  }
//setRole creates INSTANCES of the class with the STATS, maybe this can be CHANGED
  public static void setRole() {
    System.out.println("\nWhat are you?");
    System.out.println("\n\t1. Dancer \n\t2. Debater\n\t3. Designer\n\nChoose an integer.");
    
    int choice = scan.nextInt();
    if(choice == 1) {
      role = "dancer";
      symbol = "🤪";
      //♰
      maxLife = 13;
      minDamage = 2;
      maxDamage = 4;
      speed = 2;
      System.out.println("\nYou are a flexible dance enthusiast.");

      
      Character.fullHeal();
    }
    else if(choice == 2) {
      role = "debater";
      symbol = "🤓";
      maxLife = 11;
      minDamage = 2;
      maxDamage = 4;
      speed = 4;
      System.out.println("\nYou are a knowledgeable speech-maker.");
      Character.fullHeal();
    }
    else if(choice == 3) {
      role = "designer";
      symbol = "😉"; 
      //☾
      maxLife = 8;
      minDamage = 2;
      maxDamage = 3;
      speed = 6;
      System.out.println("\nYou are a crafty creater.");
      Character.fullHeal();
    }
    else {
      Character.setRole();
    }
  }
  

  public static void setMoves() {
    String nm;
    String tp;
    System.out.println("What are your moves? (stick to your type's theme, input 4 different words with enter ");
    nm = scan.nextLine();
    while(moveset.size() < 3){
      nm = scan.nextLine();
      Move c = new Move(nm, role, "nothing");
      moveset.add(c);
    }
      



    
    System.out.println("Now for your extra move. What is your extra move's name?");
     nm = scan.nextLine();
     System.out.println("What is your extra move's type." + Battle.getCategoryList() + "Choose an integer.");
    //\n\t1. Dancer \n\t2. Debater\n\t3. Designer
     tp = scan.nextLine();
     Move d = new Move(nm, tp, "nothing");
     moveset.add(d);
    
  }
  

  
  public static String getName() {
    return name;
  }
  public static ArrayList<Move> getMoveset() {
    return moveset;
  }
  public static void printMoveset() {
    for(int i = 0; i < moveset.size();i++) {
      System.out.println(moveset.get(i));
    }
  }

  public static String getRole() {
    return role;
   /* if(role.equals("dancer")) {
      return 1;
    }
    else if(role.equals("debater")) {
      return 2;
    }
    else if(role.equals("designer")) {
      return 3;
    }
    else {
      return 0;
    }*/
  }

  public static String printSymbol() {
    return symbol;
  }

  public static void gainLife(int i) {
    life += i;
  }

  public static void loseLife(int i) {
    life -= i;
  }

  public static int getLife() {
    return life;
  }

  public static int getMaxLife() {
    return maxLife;
  }

  public static int getMinDamage() {
    return minDamage;
  }

  public static int getMaxDamage() {
    return maxDamage;
  }

//if higher than the enemy speed the speed stat is used to flee
  public static int getSpeed() {
    return speed;
  }

  public static void changeMaxLife(int i) {
    maxLife += i;
  }

  public static void changeMinDamage(int i) {
    minDamage += i;
  }

  public static void changeMaxDamage(int i) {
    maxDamage += i;
  }

  public static void changeSpeed(int i) {
    speed += i;
  }

  public static void loseMinDamage(int i) {
    minDamage -= i;
  }

  public static void loseMaxDamage(int i) {
    maxDamage -= i;
  }

  public static void loseSpeed(int i) {
    speed -= i;
  }

  public static int getTotalStats() {
    int totalStats = maxLife + ((minDamage + maxDamage) / 2) + speed;
    return totalStats;
  }
}