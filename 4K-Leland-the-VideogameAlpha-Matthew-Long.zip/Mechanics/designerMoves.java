import java.util.*;
public class designerMoves extends Move {
  
  private static ArrayList<designerMoves> moveList = new ArrayList<designerMoves>();

public designerMoves(String n, String t, String cha) {
  super(n,t, cha);
  
}
  
public static void randMoves() {
    int r =  (int)(Math.random()*4);
designerMoves m1 = new designerMoves("chalkify", "designer", "nothing");
designerMoves m2 = new designerMoves("postrProd","designer","nothing");
  designerMoves m3 = new designerMoves("artistry","designer","nothing");
  designerMoves m4 = new designerMoves("camFlash","designer","flashed");
  setPosMoves(m1);
  setPosMoves(m2);
  setPosMoves(m3);
  setPosMoves(m4);
  moveList.add(m1);
  moveList.add(m2);
  moveList.add(m3);
  moveList.add(m4);
  
}
public static designerMoves getMoveinList(int i) {
  return moveList.get(i);
}
  
}