public class Potion extends Item {
  private static int potMinHeal = 4;
  private static int potMaxHeal = 6;
  


  public Potion() {
    super();
    setCategory("Potion");
    setEffect(1);
    
  }
  public Potion(String n, String cat, int min, int max) {
    super(n,cat);
    potMinHeal = min;
    potMaxHeal = max;
    setEffect(Battle.getRandInt(potMinHeal, potMaxHeal));
    
    
  }
  public void setMinPot(int min) {
    potMinHeal = min;
    setEffect(Battle.getRandInt(potMinHeal, potMaxHeal));
  }
  public void setMaxPot(int max) {
    potMaxHeal = max;
    setEffect(Battle.getRandInt(potMinHeal, potMaxHeal));
  }

  public int getEffect() {
    return super.getEffect();
  }
  
  

  
  
}