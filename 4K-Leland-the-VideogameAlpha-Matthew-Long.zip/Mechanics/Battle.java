import java.util.*;

import java.lang.*;

public class Battle {
  private static Scanner scan = new Scanner(System.in);
  private static Random rand = new Random();
  private static int choice;
  private static int act;
  private static int exp = 0;
  private static int numPots = 2;
  private static int statRestores = 1;
  private static int items = numPots + statRestores;
  
  private static String [] categories = {"debater", "designer", "dancer"};
  
  private static ArrayList<Item> inventory = new ArrayList<Item>();
 // private static String[] enemyNames = {"Undead Soldier", "Wild Boar", "Rabid Wolf", "Thief", "Phantom", "Hostile Goblin", "Dark Elf", "Tiny Drake", "Giant Spider", "Bone Vulture", "Fire Imp", "Griffin", "Vampire", "Werewolf", "Assassin", "Monkey", "Carnivorous Plant", "Rampaging Orc", "Rock Troll", "Kobold", "Skeletal Warrior", "Crocodile", "Minotaur", "Harpy"};
  //private static String[] advancedEnemies2 = {"Corrupted Mage", "Death Knight", "Blight Hound", "Abyssal Fiend"};
  private static int level = 1;
  private static int damage;
  private static String enemy;
  private static String enemyType;
  private static int enemyLife;
  private static int enemyDamage;
  private static int enemyMinDamage;
  private static int enemyMaxDamage;
  private static int enemySpeed;
  private static int minDamageChange;
  //only for specific method
  private static int maxDamageChange;
  //only for specific method
  private static int speedChange;
  private static int spGain;
  private static int battlesWon = 0;
  private static boolean flee = false;
  private static int enemiesMade = 0;
  private static String change = "nothing"; 
  private static String eChange = "nothing";
  private static Move id = new Move("helper", "grass", "nothing");
  private static boolean endTurn = false;
  private static boolean eEndTurn = false;
  private static boolean enemyAttacked = false;
  private static boolean characterAttacked = false;
  private static boolean willDo = true;
  private static Move eChosen = new Move();
  private static Move chosenMove = new Move();
  private static int previousAct = 0;
  private static int effectChance = -1;
  private static ArrayList<String> aPosNames;
  private static boolean isAdvancedEnemy = false;
  private static ArrayList<Move> allaPosMoves = new ArrayList<Move>();
  private static ArrayList<String> party = new ArrayList<String>();
  private static String currCharacter;
  
  public static void battle() {
    flee = false;

    while(Character.getLife() > 0 && enemyLife > 0) {
     if(act % 1 == 0) {
       System.out.println("\nLife: " + Character.getLife() + "/" + Character.getMaxLife() + "\n\n" + enemy + " Life: " + enemyLife);
       //Battle.changeChecker();
       }
      if(Character.getSpeed() > enemySpeed ) {
        if(endTurn == false) {
        Battle.action();
          }
        
        if(Character.getLife() <= 0 || enemyLife <= 0) {
          
          break;
        }
        

        if(flee) {
          break;
        }
        
        //System.out.println("here!");
        if(eEndTurn == false) {
        Battle.enemyAttack();
          }
        
        
        
        
      }
      else if(Character.getSpeed() < enemySpeed ) {
        if(eEndTurn == false) {
        Battle.enemyAttack();
          }
        
        if(enemyLife <= 0 || Character.getLife() <= 0) {
          break;
        }
       
        
        
        
        if(endTurn == false) {
        Battle.action();
          }
        
        if(flee) {
          break;
        }
      }
      else if(Character.getSpeed() == enemySpeed) {
        if(eEndTurn == false) {
        Battle.enemyAttack();
          }
        if(Character.getLife() <= 0 || enemyLife <= 0) {
                   break;
        }

        
         if(endTurn == false) {
        Battle.action();
           }
        
        if(flee) {
          break;
        }
      }
    }
     Battle.resetStats();
     Battle.levelUp(); 

    if(Character.getLife() < 1) {
       Character.gameOver("Bested by " + enemy);
          enemiesMade++;
    } else if(enemyLife < 1) {
          battlesWon++;
          Battle.victory();
          enemiesMade++;
    }
    
    }
    
  public static void swap() {
   // scan =
      //currCharacter =
      if(party.size() >= 2) {
      for(int i = 0; i < party.size();i++) {
      
      }
    } 
  }
   
  public static void advancedSpawning() {
    ArrayList<String> aPosNames = new ArrayList<String>(
  Arrays.asList("Kanoa","Nathan","Julia", "Daniel"));
    //Add Nick and Garrett later
    int fer = (int)(Math.random()*aPosNames.size());



//Random whichMove will be a random between that move in the movelist and 

//Ellen, 4, 8
//if(advancedEnemy.getMoveList().isEmpty()) {

    
     //advancedEnemy Nathan = new advancedEnemy("Nathan, 4, 9,");
if(advancedEnemy.getMoveList().isEmpty()) {
advancedEnemy Kanoa = new advancedEnemy("Kanoa","dancer",7, 3, 6, 7);
  
Move effectMove1 = new Move("Flash","dancer","flashed");


  
  //currently is Kanoa's moveList
      advancedEnemy.addToMoveList(effectMove1);
      advancedEnemy.addToMoveList(new Move("Voltage","dancer","nothing"));
      advancedEnemy.addToMoveList(new Move("Gunshot","dancer","nothing"));
      advancedEnemy.addToMoveList(new Move("Tempo","dancer","nothing")); 

/*effectChance = (int)(Math.random()*10)+1;

if(effectChance >= 8 && effectChance != -1) {
 willDo = true;
}*/

enemy = "Kanoa";
enemyType = "dancer";
enemyLife = 7;
enemyMinDamage = 3;
enemyMaxDamage = 6;
enemySpeed = 7;
advancedEnemy.addToAdvancedEnemies(Kanoa);

  
//NEED TO TEST ABOVE

} else {

//make every single instance of advancedEnemy
//call a random advancedEnemy from advancedEnemies in advancedEnemy class
  
//Nathan
  if(fer == 1) {
advancedEnemy.setMoveList(0, new Move("HeartSlap","dancer","nothing"));
advancedEnemy.setMoveList(1, new Move("SpinHome", "dancer", "nothing"));
advancedEnemy.setMoveList(2, new Move("CenterShine","dancer","flashed"));
advancedEnemy.setMoveList(3, new Move("FormationChange","dancer","nothing"));
    advancedEnemy Nathan = new advancedEnemy(aPosNames.get(fer),"dancer",7, 3, 6, 7);
    advancedEnemy.addToAdvancedEnemies(Nathan);
    } else if(fer == 2) {
      advancedEnemy.setMoveList(0, new Move("I see that I'm Icy","dancer","infatuated"));
advancedEnemy.setMoveList(1, new Move("MusicProd", "designer", "nothing"));
advancedEnemy.setMoveList(2, new Move("Beep Beep","dancer","nothing"));
advancedEnemy.setMoveList(3, new Move("Yes Oar Yes ","dancer","nothing"));
  advancedEnemy Julia = new advancedEnemy(aPosNames.get(fer),"dancer",7, 3, 6, 7);
    advancedEnemy.addToAdvancedEnemies(Julia);
    } else if(fer == 3) {
         advancedEnemy.setMoveList(0, new Move("blah blah blah", "debater","nothing"));
advancedEnemy.setMoveList(1, new Move("toilet throw", "designer", "nothing"));
advancedEnemy.setMoveList(2, new Move("fart", "dancer", "infatuated"));
advancedEnemy.setMoveList(3, new Move("idk", "designer","nothing"));
    advancedEnemy Daniel = new advancedEnemy(aPosNames.get(fer),"designer",7, 3, 6, 7);
    advancedEnemy.addToAdvancedEnemies(Daniel);
    } 

  //advancedEnemy Daniel = new advancedEnemy(aPosNames.get(fer),"dancer",7, 3, 6, 7);

  
enemy = aPosNames.get(fer);
enemyType = advancedEnemy.getAdvancedEnemy(fer).getType();
enemyLife = advancedEnemy.getAdvancedEnemy(fer).getLife();
enemyMinDamage = advancedEnemy.getAdvancedEnemy(fer).getMinDamage();
enemyMaxDamage = advancedEnemy.getAdvancedEnemy(fer).getMaxDamage();
enemySpeed = advancedEnemy.getAdvancedEnemy(fer).getSpeed();
//advancedEnemy.addToAdvancedEnemies(advancedEnemy.getAdvancedEnemy(fer));
  
} 
    isAdvancedEnemy = true;
    System.out.println("\n" + enemy + " challenges you!");
    Battle.battle();
    //need reference to moves list in advancedEnemy
    }

  
  
  public static void randEncounter() {
    //chooses a random enemy from the array of enemies
    Enemy e = new Enemy();
    int g = (int) (Math.random()*e.getNamesLength());
    
    
    enemy = e.getAName(g);
    
    int barr = Enemy.getBarrier();
    int count = 0;
  for(int xa = 0; xa < Enemy.getNamesLength(); xa++) {
      if(g < barr) {
        e.setType("dancer");
        enemyType = "dancer";
      } else if(g >= (barr) && g < barr*2) {
        enemyType = "debater";
        e.setType("debater");
      } else if(g >= barr*2 && g < (barr*3)) {
        e.setType("designer");
        enemyType = "designer";
      }
 }
  
    //your character level determines the strength of the enemy from the multiplication
    int raf = getRandInt((3 * level), (9 * level));
    e.setLife(raf);
    enemyLife = raf;

    
    int ref = getRandInt((level), (6 * level));
    System.out.println(ref);
    enemySpeed = ref;
    e.setSpeed(ref);
    enemyMinDamage = level;
    e.setMinDamage(level);
    enemyMaxDamage = 4 * level;
    e.setMaxDamage(4*level);
    Enemy.addtoCurr(e);
    
    System.out.println("\n" + enemy + " challenges you!");
    Battle.battle();
  }

  


/*public static void randAdvancedEncounter() {
Random ran = new Random();
    enemy =     Enemy.getAdvancedEnemy(ran.nextInt(advancedEnemies.size()));
    enemyLife = Battle.getRandInt((5 * level), (10 * level));
    enemySpeed = Battle.getRandInt((3 * level), (6 * level)));
    enemyMinDamage = 2 * level;
    enemyMaxDamage = 4 * level;
    System.out.println("\n" + enemy + " approaches!");
    Battle.battle();
  }*/

  

 

  

  public static void action() {
    System.out.println("\n\t1. Attack\n\t2. Use potion\n\t3. Switch\n\t4. Flee");
    act = scan.nextInt();
    if(act == 1) {
      
      Battle.attack();
      
    }
    else if(act == 2) {
     
      Battle.useItem();
      
    } else if(act == 3) {
      Battle.swap();
    } else if(act == 4) {
      Battle.flee();
    }
    
  }
  public static void compareType(String r) {
    //Debater super effective towards designer, designer super effective towards dancer, dancer super effective towards debater
enemyType = Enemy.getCurrType(enemiesMade);
    
    
    if(enemyType.equals(r)) {
      enemyDamage--;
      //damage is global
      damage--;
    } else if(enemyType.equals("debater") && r.equals("designer")) {
      enemyDamage+=2;
    }
    else if(enemyType.equals("designer") && r.equals("debater")) {
      damage+=2;
    } else if(enemyType.equals("designer") && r.equals("dancer")) {
      enemyDamage+=2;
    }
    else if(enemyType.equals("dancer") && r.equals("designer")) {
      damage+=2;
    } 
    else if(enemyType.equals("dancer") && r.equals("debater")) {
      enemyDamage+=2;
    }
    else if(enemyType.equals("debater") && r.equals("dancer")) {
      damage+=2;
    }

  
    }
  public static void changeChecker() {
    //System.out.println("I'm in");
    //infatuated be saved as something else
    
    int ran = (int)(Math.random()*4);
    int r = (int) (Math.random()*2); 
    if(enemyAttacked == true && endTurn == false) {
      eChange = chosenMove.getStatusChange();
    }
    else if(characterAttacked == true && eEndTurn == false && !(change.equals("healed"))) {
      change = eChosen.getStatusChange();
    }

    

//poisoned,
    if(change.equals("nothing")) {
      change = "nothing";
    }
    if(eChange.equals("nothing")) {
      eChange = "nothing";
    }
    if(change.equals("healed")) {
      change = "nothing";
      System.out.println("You have been healed from ever taking statusEffects for the rest of this battle");
    }
    
    if(change.equals("tongue-tied")) {
      //debaters can make people tongue-tied like paralysis
      eChosen = debaterMoves.getMoveinList(ran);
      System.out.println( Character.getName() + " is paralyzed, " + enemy + " gets another turn");
      System.out.println("\n" + enemy + " attacks with " + eChosen.getName() + " for " + enemyDamage + " damage!");
    Character.loseLife(enemyDamage);
      
    } else if(change.equals("confused")) {
      //designers can confuse people and make them attack themselves in confusion
      //Battle.confused();
    } else if(change.equals("infatuated")) {
      System.out.println(Character.getName() + " is infatuated," + enemy + "gets another turn");
    }
    else if(change.equals("flashed")) {
      //dancers can make people flashed and half the time not attack
     eChosen = designerMoves.getMoveinList(ran);
      System.out.println( Character.getName() + " has been flashed, " + enemy + " gets another turn");
      System.out.println("\n" + enemy + " attacks with " + eChosen.getName() + " for " + enemyDamage + " damage!");
    Character.loseLife(enemyDamage);
        
      
    }
//ENEMY ATTACKED VERSION
    if(eChange.equals("tongue-tied")) {
      //debaters can make people tongue-tied like paralysis
      System.out.println(enemy + " is paralyzed, you get another turn");
      Battle.action();
      
    } else if(eChange.equals("confused")) {
      //designers can confuse people and make them attack themselves in confusion
      //Battle.confused();
    } else if(eChange.equals("infatuated")) {
      //dancers can make people infatuated and half the time not attack
      int f = (int) (Math.random()*2);

      if(f == 0) {
      System.out.println(enemy + " is infatuated," + Character.getName() + "gets another turn");
      }
      else if(eChange.equals("flashed")) {
        System.out.println(enemy + " is flashed, " + Character.getName() + " gets another turn");
        Battle.action();
      }
    }

 

    
    
  }

  

  public static void attack() {
    //attack dmg is random roll between minimum damage to maximum damage
    damage = getRandInt(Character.getMinDamage(), Character.getMaxDamage());
    String t = null;
    String c = null;
//make a move
   
    
    
    System.out.println("Which move will you choose?");
    System.out.println("\n\t1." + Character.getMoveset().get(0).getName() + "\n\t2." + Character.getMoveset().get(1).getName() + "\n\t3." + Character.getMoveset().get(2).getName() + "\n\t4." + Character.getMoveset().get(3).getName() + "\n\t5. Back");
    //move.getDmg() and move.getName()
    t = Character.getMoveset().get(0).getType();
    choice = scan.nextInt();
   if(choice == 1) {
      chosenMove = Character.getMoveset().get(0);
      c = Character.getMoveset().get(0).getName();
      t = Character.getMoveset().get(0).getType();
  } else if(choice  == 2) {
       chosenMove = Character.getMoveset().get(1);
       c = Character.getMoveset().get(1).getName();
       t = Character.getMoveset().get(1).getType();
  } else if(choice  == 3) {
       chosenMove = Character.getMoveset().get(2);
       c = Character.getMoveset().get(2).getName();
       t = Character.getMoveset().get(2).getType();
  } else if(choice  == 4) {
       chosenMove = Character.getMoveset().get(3);
       c = Character.getMoveset().get(3).getName();
       t = Character.getMoveset().get(3).getType();
  } else if(choice == 5) {
     previousAct = 5;
     Battle.action();
  }
    String rep = null;
    int note = damage;
    
    compareType(t);
    if(note > damage) {
      rep = "The attack was not very effective...";
    } else if(note < damage) {
      rep = "The attack was super effective!";
    } else {
      rep = "";
    }
    
    
    if(previousAct != 5) {
    System.out.println("\nYou attack the " + enemy + " with " + c  +" for " + damage + " damage! " + rep);
      enemyLife -= damage;
      enemyAttacked = true;
    //what about double moves
      
  
id.setType("seed");
   // turns++;
   // endTurn = true;
   // eEndTurn = false;
      
      }
  }
  public static void enemyAttack() {
   boolean noEAttack = true;

    


//System.out.println("\n\n" + enemyType);
    
    enemyDamage = getRandInt(enemyMinDamage, enemyMaxDamage);
    String eCho = null;
    int ra = (int)(Math.random()*4);
if(isAdvancedEnemy == false) {
  for(int i = 0; i < categories.length;i++) {
    if(enemyType.equals(categories[i])) {
      if(enemyType.equals("dancer")) {
        dancerMoves.randMoves3();
        eCho = dancerMoves.getMoveinList(ra).getName();
        eChosen = dancerMoves.getMoveinList(ra);
      } else if(enemyType.equals("debater")) {
        debaterMoves.randMoves2();
        eChosen = debaterMoves.getMoveinList(ra);
         eCho = debaterMoves.getMoveinList(ra).getName();
      } else if(enemyType.equals("designer")) {
        designerMoves.randMoves();
         eCho = designerMoves.getMoveinList(ra).getName();
        eChosen = designerMoves.getMoveinList(ra);
      } 
    }
    }
  } else if(isAdvancedEnemy) {
    eChosen = advancedEnemy.getMoveinMoveList(ra);
    eCho = advancedEnemy.getMoveinMoveList(ra).getName();
  }
    
  
   //IF STATEMENTS FOR SPECIFIC MOVES-KANOA 
    if(eChosen.getName().equals("Flash")) {
      effectChance = (int)(Math.random()*10)+1;

    if(effectChance >= 8 && effectChance != -1) {
     willDo = true;
     }
    }

  if(eChosen.getName().equals("Tempo")) {
    noEAttack = false;
    enemyMinDamage++;
    enemyMaxDamage++;
  }



    
    
  if(noEAttack) {
    System.out.println("\n" + enemy + " attacks with " + eCho + " for " + enemyDamage + " damage!");
    Character.loseLife(enemyDamage);
    characterAttacked = true;
    }
    
    if(willDo) {
    changeChecker();
    }
    
  
    //endTurn = false;
    //eEndTurn = true;
    //turns++;
    
  }
  
  public static String getCategoryList() {
    String s = "\n\t";
    for(int i = 0; i < categories.length; i++) {
      s += (i+1) + "." +(categories[i] + "\n\t");
    }
    return s;
  }


  public static void resetStats() {
    Character.loseMinDamage(minDamageChange);
    Character.loseMaxDamage(maxDamageChange);
    Character.loseSpeed(speedChange);
    minDamageChange = 0;
    maxDamageChange = 0;
    speedChange = 0;
  }

  public static void useItem() {
    if(items > 0) {
System.out.println("Which item will you choose?  \n\t-1. Back to Choices");
      System.out.println(Character.printItemList());
      choice = scan.nextInt();
      if(choice == -1) {
        Battle.action();
      } 
      else if(Character.getItem(choice-1).getCat().equals( "Potion")) {
      if(numPots > 0) {
      int potHeal = Character.getItem(choice-1).getEffect();
      Character.gainLife(potHeal);
      if(Character.getLife() > Character.getMaxLife())      {
        Character.fullHeal();
      }
      numPots--;
      Character.removeFromInventory(choice-1);
      System.out.println("\nYou drink a potion, restoring " + potHeal + " life.");
      System.out.println("\nYou have " + numPots + " potions remaining.");
        }
      } else if(Character.getItem(choice-1).getCat().equals( "statusRestore")) {
      if(statRestores > 0) {
        if(!(change.equals("healed")) || !(change.equals("nothing"))) {
      change = "cured";
      statRestores--;
      Character.removeFromInventory(choice-1);
      System.out.println("\nYou use a status restore, restoring " + change + "effect.");
      System.out.println("\nYou have " + statRestores  + " statusRestores remaining.");

      /*if(statRestores > 0) {
      int change = ;
      Character.batStatus();
      if(Character.getLife() > Character.getMaxLife()) {
        Character.heal();
      }
      numPots--;
      System.out.println("\nYou use a status restore, restoring " + change + "effect.");
      System.out.println("\nYou have " + numPots + " potions remaining.");
        } */} else if(change.equals("healed") || change.equals("nothing")) {
      System.out.println("You have no statusChange affecting you right now!");
      } 
    } 
    }
      items = numPots + statRestores;
System.out.println("\nYou have " + items + " items remaining.");
   
  }
      
    items = numPots + statRestores;
    if(items == 0) {
    System.out.println("\nYou don't have any items!");
      }
      //endTurn = true;
      
    }

  public static void makePotions() {
      Potion MountainDew = new Potion("MountainDew","Potion",2,5);
    Potion Lemonade = new Potion("Lemonade","Potion",3,6);
    Potion Boba = new Potion("Boba","Potion",8,10);
    Potion ArizonaJuice = new Potion("ArizonaJuice", "Potion",4,8);
    ArrayList<Potion> pots = new ArrayList<Potion>(Arrays.asList(MountainDew, Lemonade, ArizonaJuice, Boba));

  
   for(int i = 0; i < numPots; i++) {
     Character.addToInventory(pots.get(i));
     inventory.add(pots.get(i));
   }
   

    
  }

  public static void flee() {
    if(Character.getSpeed() > enemySpeed) {
      System.out.println("\nYou ran away!");
      flee = true;    
    }
    else {
      int fleeChance = rand.nextInt(1);
      if(fleeChance == 0) {
        System.out.println("\nYou ran away!");
        flee = true;
      }
      else {
        System.out.println("\nYou can't escape!");
      }
    }
  }

  public static void victory() {
    System.out.println("\nYou are victorious!");
    if(battlesWon == 2) {
      Character.gainLife(4);
    }
    spGain = getRandInt(2, 5);
    Shop.changePoints(spGain);
    System.out.println("\nYou gained " + spGain + " Spirit Points!");
    //Battle.passiveAbility();
    exp += getRandInt(2,5);
    System.out.println("You gained " + exp + " experience points");
  }

 

  /*public static void passiveAbility() {
    if(Character.getRole() == 1) {
      int i = rand.nextInt(3);
      if(i == 0) {
        System.out.println("\nYour knightly valor grants you bonus max life.");
        Character.changeMaxLife(1);
      }
    }
    else if(Character.getRole() == 2) {
      System.out.println("\nYou adventurous soul regenerates some of your missing life.");
      Character.gainLife(getRandInt((level), (3 * level)));
      if(Character.getLife() > Character.getMaxLife()) {
        Character.heal();
      }
    }
    else if(Character.getRole() == 3) {
      int i = rand.nextInt(3);
      if(i == 0) {
        System.out.println("\nYour murderous instinct grants you bonus max damage.");
        Character.changeMaxDamage(1);
      } 
    }
  }*/

  public static void levelUp() {
    if(exp >= (50 * level)) {
      level++;
    }
  }

  public static int getNumPots() {
    return numPots;
  }

  public static void changeNumPots(int i) {
    numPots += i;
    items = numPots + statRestores;
  }
  
  public static void changeNumRestores(int i) {
    statRestores += i;
    items = numPots + statRestores;
  }

  
  public static int getRandInt(int min, int max) {
    int range = max - min;
    return new Random().nextInt(range + 1) + min;
  }
}